<?php
echo md5('php_ok');